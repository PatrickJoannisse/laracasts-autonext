# Laracasts autonext

This is a simple extension to allow Laracasts to play the next video automatically.
